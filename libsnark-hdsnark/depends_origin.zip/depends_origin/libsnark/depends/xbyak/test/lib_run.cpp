#include "lib.h"

int main()
{
	puts("main");
	X::a.put();
	putReg();
}

